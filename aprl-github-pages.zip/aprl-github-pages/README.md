# APRL GitHub Pages Static Site

This is a multi-page static website template for the **Advanced Propulsion Research Laboratory (APRL)** at IISc Bangalore.

## Files
- `index.html` – homepage
- `about.html` – about the lab and PI
- `research.html` – research themes
- `people.html` – students, interns, and alumni
- `publications.html` – selected publications
- `positions.html` – openings and application guidance
- `news.html` – news and updates
- `contact.html` – contact information
- `assets/styles.css` – shared stylesheet

## How to use with GitHub Pages
1. Create a new GitHub repository.
2. Upload all files in this folder to the repository root.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose:
   - **Source:** Deploy from a branch
   - **Branch:** `main` (or `master`)
   - **Folder:** `/root`
5. Save. GitHub will publish the site with the generated URL.

## Suggested next edits
- Add lab and student photos in an `assets/images/` folder.
- Add DOI or PDF links to publications.
- Add a Google Scholar link and faculty profile.
- Replace placeholder news items with current announcements.
- Add a custom domain later if needed.

## Notes
This version is fully static and does not require React, Node, or a build step.